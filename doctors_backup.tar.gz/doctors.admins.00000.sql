/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `admins` VALUES(60,161,"effety@gmail.com",NULL,"$2y$12$M5gjkYciGcU81Qqg7x2AFO0l7yk3ZrIwBauUgQ5YS3uhFP2wLJ7Cm","user","1",NULL,NULL,"2024-06-06 03:24:20","2024-06-06 03:25:28")
,(61,162,"admin@gmail.com",NULL,"$2y$12$fTNRqX9t6K21fqBYf/KI2eq432er6/O3p.yLBjsUuu6IpoL43GpKC","admin","1",NULL,"WARDO56GAGBAHHPC","2024-06-06 12:19:18","2024-09-09 05:55:21")
,(63,1,"sarah@gmail.com",NULL,"$2y$12$M5gjkYciGcU81Qqg7x2AFO0l7yk3ZrIwBauUgQ5YS3uhFP2wLJ7Cm","patient","1",NULL,NULL,"2024-06-11 03:22:11","2024-06-11 04:10:18")
,(98,3990,"info@gmviva.ch",NULL,"$2y$12$fEFWlHvcEhExEw7E4PZGiuVPIPRFnn76LjAjyemhD/.JFmoWqQ/OS","user","1",NULL,NULL,"2025-02-12 07:17:00","2025-02-12 07:17:00")
,(99,3991,"jahedrabbi10@gmail.com",NULL,"$2y$12$BpzkQdxI36/UtqXiA389M.BxslwtkT8XIrx2XIFouHon020ZK5uee","user","1",NULL,NULL,"2025-03-03 08:55:04","2025-03-03 08:55:04")
,(100,3992,"verenabonny@hotmail.com",NULL,"$2y$12$2Z/t5Io2ilRPQo9upBYa6ujRsLXdRrEgM0enUBhXIdkulgat649ZG","user","1",NULL,NULL,"2025-03-04 08:57:54","2025-03-04 08:57:54")
,(101,3993,"info@wallmed.ch",NULL,"$2y$12$4z5Kd4t6Hw1BoDGGmJbXOOHSOy3wkIKBVUwrp1yoGhjCAc4uug4bi","user","1",NULL,NULL,"2025-03-04 08:59:13","2025-03-04 08:59:13")
,(102,3994,"nivan741@gmail.com",NULL,"$2y$12$kTpNXKIdjUiqmpQqWiP7OeE/kb50ftfTY2YRpYfBR4aE5aSlYkhiy","user","1",NULL,NULL,"2025-03-06 08:49:13","2025-03-06 08:49:13")
,(103,3995,"jessougarcia@gmail.com",NULL,"$2y$12$gxmnu8gP287tKQyOwmUZOeV8FnhN9LnEXIMdWmKZnzIZemfXqTJ3u","user","1",NULL,NULL,"2025-03-06 09:59:05","2025-03-06 09:59:05")
,(104,3996,"mukulneo200@gmail.com",NULL,"$2y$12$h9Ig1oPuLPaQXFMO3kvq4OhQrFZ3h/ZpCSJASPk1ocJTuhrLAs2RK","user","1",NULL,NULL,"2025-03-06 16:28:22","2025-03-06 16:28:47")
,(105,11,"lyons08978tyson@gmail.com",NULL,"$2y$12$MkIq1iiG9ltV2Z6wNzF.Uu15O78bohkpulHmowaqygx.cXCUtl/Pe","patient","1",NULL,NULL,"2025-03-07 07:32:53","2025-03-07 07:32:53")
,(106,12,"gmneumed@gmail.com",NULL,"$2y$12$8eaC6jeCrYXpkj49h75vguaydh.EdZ3.tuzbMOkdqoZZNaI1PeuiK","patient","1",NULL,NULL,"2025-03-07 12:47:55","2025-03-07 12:47:55")
,(107,3997,"aqsaxshoaib@gmail.com",NULL,"$2y$12$UJh/uUH7uY7dhHfrt7ctv.3/loEoELNgw5oNxM2FRQMZ5RbD7Knrm","user","1",NULL,NULL,"2025-03-09 20:22:29","2025-03-09 20:23:37")
,(108,3998,"phone@triol.site",NULL,"$2y$12$m1hDLa8JJNACIAsl3ixoZerR.pw1kNhi/ylRdn95R25DmyE10owL.","user","0",NULL,NULL,"2025-03-11 03:05:26","2025-03-11 03:05:26")
,(109,13,"cemeta5700@doishy.com",NULL,"$2y$12$C.gsIuKtf0jHDz/frgcbIO1ckmmVvPmIPqcFEmN515v9eUlKDS9s.","patient","1",NULL,NULL,"2025-03-13 18:41:12","2025-03-13 18:41:12")
,(110,3999,"jixone4563@doishy.com",NULL,"$2y$12$bE9qip4NGQFP.5HlhNOS7OfK2ekzVxahdwi/JeJJIlOiSsm7AjW0m","user","1",NULL,NULL,"2025-03-13 18:49:38","2025-03-13 18:50:11")
,(111,4000,"pavovom601@erapk.com",NULL,"$2y$12$ZN1WXf1NyPQLwLM.NrBC7OBwpgCgREoeF5ei8BH0oGoCY3gQIxhuq","user","1",NULL,NULL,"2025-03-13 19:02:28","2025-03-13 19:02:50")
,(112,4003,"safasw414@gmail.com",NULL,"$2y$12$mvCY7eR0VrmBHETmqem4X.3i2SEPOVVoozD.XL3v.54t7aw09/iiC","user","0",NULL,NULL,"2025-03-25 00:14:28","2025-03-25 00:14:28")
;
