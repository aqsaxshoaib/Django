/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `chats` VALUES(94,1,3,"5qa-xky-opn","finished","2024-05-04 17:20:15","2024-05-04 20:36:45")
,(95,1,4,"jc1-fq6-gla","finished","2024-05-17 23:02:25","2024-05-17 23:23:23")
,(96,1,2,"nsi-qgm-a45","finished","2024-05-17 23:40:28","2024-05-17 23:41:06")
,(97,1,4,"vo8-76c-a2f","finished","2024-05-29 05:24:37","2024-05-29 05:25:30")
,(98,1,4,"o62-1lt-by8","finished","2024-05-29 05:26:26","2024-05-29 05:27:05")
,(99,1,4,"t7d-ukw-nsq","finished","2024-05-29 05:27:58","2024-05-29 05:30:36")
,(100,1,4,"q7u-b6r-tcw","finished","2024-05-29 05:31:04","2024-05-29 05:31:15")
,(101,1,4,"0w2-icy-daj","finished","2024-05-29 05:31:24","2024-05-29 05:31:33")
,(102,1,4,"4ni-qw6-bh3","finished","2024-05-29 05:34:45","2024-05-29 05:46:07")
,(103,1,4,"5k1-0i3-jn2","finished","2024-05-29 05:47:15","2024-05-29 05:54:16")
,(104,1,4,"cen-fkr-t2y","finished","2024-05-29 06:22:22","2024-05-29 06:31:42")
;
