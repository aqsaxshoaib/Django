/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `coupons` VALUES(1,"Allomed","Allomed","741852741","coupon","Paid",10.00,0.00,10,"doctor-panel/coupons_categories/1735720586_Encrypt.png","2024-11-27","active","2024-11-24 18:24:24","2025-01-01 07:36:26")
,(2,"Polso","Polso","789456123","coupon","Free",0.00,0.00,3,"doctor-panel/coupons_categories/1735720607_d3.jpg","2024-12-06","active","2024-11-24 18:26:10","2025-01-01 07:36:47")
,(3,"Doctomed","Doctomed","123456789","coupon","Refferal",0.00,0.00,8,"doctor-panel/coupons_categories/1735720621_p1-removebg-preview.png","2024-11-28","active","2024-11-24 18:27:47","2025-01-01 07:37:01")
,(4,"Get Peacock Premium Plus For a month","Get Peacock Premium Plus For a month","5465423","giftcard","Paid",16.00,1.00,1,"doctor-panel/coupons_categories/1735720632_def.png","2024-12-05","active","2024-11-24 18:59:23","2025-01-01 07:37:12")
,(5,"Amazon","Amazon","54634343","coupon","Paid",10.00,0.00,15,"doctor-panel/coupons_categories/1735720646_logo-removebg-preview.png","2024-12-16","active","2024-12-06 22:16:53","2025-01-01 07:37:26")
,(6,"Amazon Prime Premium Plus For a month / 150.00 CHF",NULL,"sads23456","giftcard","Paid",150.00,0.00,12,"doctor-panel/coupons_categories/1735720670_def.png","2024-12-19","active","2024-12-06 22:18:28","2025-01-01 07:37:50")
;
