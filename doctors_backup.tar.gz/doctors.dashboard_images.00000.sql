/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `dashboard_images` VALUES(2,"top",2,"images/1742411421_female-avi2.jpg","dashboard_images/1742411929_icon_images.jpg","https://doctomed.ch/admin/admin/","2025-03-19 13:10:21","2025-03-20 08:18:16")
,(3,"top",1,"dashboard_images/1742411830_background_images.jpg","dashboard_images/1742412721_icon_556ba243745f11ee8ab32aa0df1cd6e5_upscaled.jpg","https://doctomed.ch/admin/admin/dashboard-images","2025-03-19 13:17:10","2025-03-19 13:32:01")
,(4,"top",3,"dashboard_images/1742412753_background_a656235b-aa33-46dd-8a9b-42e2619bcf4a.jpeg","dashboard_images/1742412753_icon_crypto1.jpg","https://doctomed.ch/admin/admin/dashboard-images","2025-03-19 13:32:33","2025-03-19 13:32:33")
,(5,"top",4,"dashboard_images/1742412787_background_1724833859_66cee043808fd.jpg","dashboard_images/1742412787_icon_crypto1.jpg","https://doctomed.ch/admin/admin/dashboard-images","2025-03-19 13:33:07","2025-03-19 13:33:07")
,(6,"bottom",1,"dashboard_images/1742412931_background_a656235b-aa33-46dd-8a9b-42e2619bcf4a.jpeg","dashboard_images/1742412931_icon_crypto1.jpg","https://doctomed.ch/admin/admin/dashboard-images","2025-03-19 13:35:31","2025-03-19 13:35:31")
,(7,"top",1,"dashboard_images/1742478980_background_8aa682a7-820e-4826-8a7d-b52438a3ad37.jpeg","dashboard_images/1742478980_icon_d561656e-a692-41d2-a455-d30477a3b079.jpeg","https://doctomed.ch/admin/admin/dashboard-images","2025-03-20 07:56:20","2025-03-20 07:56:20")
,(8,"bottom",2,"dashboard_images/1742479999_background_d561656e-a692-41d2-a455-d30477a3b079.jpeg","dashboard_images/1742479999_icon_hourglass.png","https://doctomed.ch/admin/admin/dashboard-images","2025-03-20 08:13:19","2025-03-20 08:13:19")
,(9,"bottom",3,"dashboard_images/1742480014_background_d561656e-a692-41d2-a455-d30477a3b079.jpeg","dashboard_images/1742480014_icon_hourglass.png","https://doctomed.ch/admin/admin/dashboard-images","2025-03-20 08:13:34","2025-03-20 08:13:34")
,(10,"bottom",4,"dashboard_images/1742480042_background_Slot_time.png","dashboard_images/1742480042_icon_stethoscope.png","https://doctomed.ch/admin/admin/dashboard-images","2025-03-20 08:14:02","2025-03-20 08:14:02")
;
