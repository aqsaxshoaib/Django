/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `django_content_type` VALUES(1,"admin","logentry")
,(3,"auth","group")
,(2,"auth","permission")
,(4,"auth","user")
,(5,"contenttypes","contenttype")
,(7,"doctors","user")
,(6,"sessions","session")
;
