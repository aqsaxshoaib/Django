/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `django_migrations` VALUES(1,"contenttypes","0001_initial","2025-03-28 22:04:54.836681")
,(2,"auth","0001_initial","2025-03-28 22:04:55.016619")
,(3,"admin","0001_initial","2025-03-28 22:04:55.070608")
,(4,"admin","0002_logentry_remove_auto_add","2025-03-28 22:04:55.078108")
,(5,"admin","0003_logentry_add_action_flag_choices","2025-03-28 22:04:55.085414")
,(6,"contenttypes","0002_remove_content_type_name","2025-03-28 22:04:55.133726")
,(7,"auth","0002_alter_permission_name_max_length","2025-03-28 22:04:55.166896")
,(8,"auth","0003_alter_user_email_max_length","2025-03-28 22:04:55.189729")
,(9,"auth","0004_alter_user_username_opts","2025-03-28 22:04:55.197412")
,(10,"auth","0005_alter_user_last_login_null","2025-03-28 22:04:55.225247")
,(11,"auth","0006_require_contenttypes_0002","2025-03-28 22:04:55.232840")
,(12,"auth","0007_alter_validators_add_error_messages","2025-03-28 22:04:55.241158")
,(13,"auth","0008_alter_user_username_max_length","2025-03-28 22:04:55.274382")
,(14,"auth","0009_alter_user_last_name_max_length","2025-03-28 22:04:55.304358")
,(15,"auth","0010_alter_group_name_max_length","2025-03-28 22:04:55.321203")
,(16,"auth","0011_update_proxy_permissions","2025-03-28 22:04:55.328760")
,(17,"auth","0012_alter_user_first_name_max_length","2025-03-28 22:04:55.364794")
,(18,"doctors","0001_initial","2025-03-28 22:05:41.537683")
,(19,"sessions","0001_initial","2025-03-28 22:08:37.141643")
;
