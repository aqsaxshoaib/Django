/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `doctor_networks` VALUES(1,"ArgoMed","1",NULL,NULL)
,(2,"Geneva Network\nMediX","1",NULL,NULL)
,(3,"1A-Hausärzte","1",NULL,NULL)
,(4,"doccare – Hausärzte","1",NULL,NULL)
,(5,"DocNet Säuliamt","1",NULL,NULL)
,(6,"hapmed - Ärztenetzwerk am Pfannenstiel","1",NULL,NULL)
,(7,"Zmed","1",NULL,NULL)
,(8,"zu:care","1",NULL,NULL)
,(9,"Zürcher Gesundheitsnetz ZGN","1",NULL,NULL)
,(10,"Medbase","1",NULL,NULL)
,(11,"IfA","1",NULL,NULL)
,(12,"Hirslanden","1",NULL,NULL)
,(13,"Delta","1",NULL,NULL)
,(14,"REMED","1",NULL,NULL)
;
