/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `job_categories` VALUES(3,"Home health aide","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
,(4,"Medical assistant","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
,(5,"Nursing assistant","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
,(6,"Physical therapy assistant","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
,(7,"Licensed practical nurse","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
,(8,"Registered nurse","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
,(9,"Occupational therapist","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
,(10,"Physical therapist","active","2024-08-15 03:41:00","2024-08-15 03:41:00")
;
