/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `necessary_categories` VALUES(7,"Health and Medical services","1","2024-06-20 09:15:41","2024-11-16 12:48:44")
,(9,"General Emergency","1","2024-11-10 15:32:29","2024-11-10 15:32:29")
,(10,"Police Department","1","2024-11-10 15:32:41","2024-11-10 15:32:41")
,(11,"Ambulance Services","1","2024-11-10 15:32:54","2024-11-10 15:32:54")
,(12,"Health and Medical Services","1","2024-11-10 15:33:06","2024-11-10 15:33:06")
,(13,"Mental Health and Crisis Support","1","2024-11-10 15:33:20","2024-11-10 15:33:20")
,(14,"Suicide Prevention Lifeline","1","2024-11-10 15:33:42","2024-11-10 15:33:42")
,(15,"Specialized medical emergency","1","2024-11-11 08:48:02","2024-11-11 08:48:02")
,(16,"Addiction Helplines","1","2024-11-11 08:48:19","2024-11-11 08:48:19")
,(17,"COVID-19 hotlines and vaccination centers","1","2024-11-11 08:50:48","2024-11-11 08:50:48")
,(18,"Domestic Violence Support Centers","1","2024-11-11 08:51:24","2024-11-11 08:51:24")
,(19,"Disaster Management Agency","1","2024-11-11 08:51:50","2024-11-11 08:51:50")
,(46,"Police Department","1","2024-11-10 15:32:41","2024-11-10 15:32:41")
;
