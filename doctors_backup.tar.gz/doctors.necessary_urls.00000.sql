/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `necessary_urls` VALUES(10,7,"MAYO HOSPITAL AND EMERGENCY ROOMS","we believe in building strong, trusting relationships with my patients, ensuring they feel heard, understood, and supported. Outside of the clinic, I enjoy [your hobbies/interests], which help me maintain a balanced and fulfilling life.","01857410140","jahedrabbi10@gmail.com","1731764579_6738a163062b3.png","mirpur dhaka","active","2024-06-22 17:02:49","2024-11-16 12:44:53")
,(11,9,"Disaster Management Agency","Domestic Violence Support Centers","12345678","eff@gmailcom","1731319514_6731d6daf1433.jpg","1801, Zurich","active","2024-11-11 09:05:14","2024-11-11 09:05:14")
,(13,7,"Boston Children\'s Hospital Emergency Department","Boston Children\'s Hospital Emergency Department specializes in pediatric emergency care, providing top-notch, 24/7 critical services for children in urgent medical situations.","12345678","effety@gmail.com","1731319930_6731d87a0cd5d.png","1801, Zurich","active","2024-11-11 09:12:10","2024-11-11 09:12:10")
,(14,7,"CITY MD CARE","CityMD provides accessible, walk-in medical care for minor illnesses and injuries. They offer fast, convenient services like flu shots, COVID-19 testing, and urgent treatments, aiming to bridge the gap between primary care and emergency rooms.","01989154755","nivan@gmail.com","1732488192_6743ac0025f4f.png","Zurich, Switzerland","active","2024-11-24 21:43:12","2024-11-24 21:43:12")
;
