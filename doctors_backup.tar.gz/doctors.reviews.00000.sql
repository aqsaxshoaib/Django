/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `reviews` VALUES(1,161,"Effety hassan","effety@gmail.com",4,"Doctors reviews test","pending","2024-07-10 20:53:47","2024-07-10 20:53:47")
,(2,161,"test","jahedrabbi10@gmail.com",4,"test","accepted","2024-07-11 20:06:40","2024-07-11 20:06:40")
,(3,161,"Sarah","sarah@gmail.com",5,"best doctor","accepted","2025-03-25 11:47:27","2025-03-25 11:47:27")
;
