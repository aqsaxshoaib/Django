/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `settings` VALUES(1,"Doctors point","161",NULL,"Copyright © 2024 MEDIPOLE SA - Montreux Switzerland",NULL,"MEDIPOLE SA",NULL,NULL,"https://demo.com","upload/website/1575020462.png","upload/website/91600126.jpg","2024-08-16 16:55:45","2024-11-25 19:35:26")
,(2,"Medical Services","3975","Dr. Schenker Jean-Martin offers comprehensive medical services, specializing in General Internal Medicine and telemedicine. With a focus on patient-centered care, he is dedicated to improving your health and well-being through personalized treatment and consultations.","All Rights Reserved. Powered by Dr. Schenker Jean-Martin.",NULL,"Dr. Schenker Jean-Martin","Telemedicine, Family Doctor, General Internal Medicine, Healthcare, Medical Services, Aigle, Switzerland, Patient Care","#Telemedicine #FamilyDoctor #Healthcare #GeneralInternalMedicine #PatientCare #MedicalAdvice #Aigle","https://doctomed.ch/SchenkerJean-Martin","upload/website/1414046572.png",NULL,"2024-11-05 12:38:01","2024-11-05 14:26:29")
;
