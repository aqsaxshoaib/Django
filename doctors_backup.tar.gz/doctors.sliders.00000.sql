/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `sliders` VALUES(15,"https://allomed.ch/","1719846012_6682c47c5c40f.png","home","2024-07-01 13:00:12","2024-07-01 13:00:12")
,(23,"http://www.vertpre.com/EN/Home.html","1724835855_66cee80f5803c.jpg","home","2024-08-28 07:04:15","2024-08-28 07:04:15")
,(24,"https://www.mylabpoint.ch","1724835904_66cee8400c9ac.jpg","home","2024-08-28 07:05:04","2024-08-28 07:05:04")
,(25,"https://affidea.ch/fr/","1724835934_66cee85ecfee6.jpg","home","2024-08-28 07:05:34","2024-08-28 07:05:34")
,(26,"https://physio-clinics.ch","1724836011_66cee8ab6a747.jpg","home","2024-08-28 07:06:51","2024-08-28 07:06:51")
,(28,"https://physio-clinics.ch","1724942929_66d08a5139ac3.jpg","proPanel","2024-08-29 12:48:49","2024-08-29 12:48:49")
,(30,"https://allomed.ch/","1726403991_66e6d5976235f.png","companyPanel","2024-09-15 10:39:51","2024-09-15 10:39:51")
,(31,"https://doctomed.ch/","1729834828_671b2f4c61d35.png","proPanel","2024-10-25 03:40:28","2024-10-25 03:40:28")
,(32,"patient slider","1741692169_67d01d0912b0d.png","patientPanel","2025-03-11 10:22:49","2025-03-11 10:22:49")
,(33,"patient slider2","1741692229_67d01d45c444b.jpg","patientPanel","2025-03-11 10:23:49","2025-03-11 10:23:49")
,(34,"patient slider3","1741692261_67d01d658ec69.jpg","patientPanel","2025-03-11 10:24:21","2025-03-11 10:24:21")
,(35,"patient slider4","1741692329_67d01da91e69a.jpg","patientPanel","2025-03-11 10:25:29","2025-03-11 10:25:29")
,(36,"patient slider5","1741692366_67d01dce28e25.jpg","patientPanel","2025-03-11 10:26:06","2025-03-11 10:26:06")
;
