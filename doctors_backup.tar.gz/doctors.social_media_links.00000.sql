/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `social_media_links` VALUES(1,161,"https://www.xiju.com.au",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,"2024-11-03 08:55:32","2024-11-03 08:55:32")
,(2,3975,"https://facebook.com/","https://wa.me/","https://youtube.com/","https://instagram.com/","https://tiktok.com/","https://t.me/","https://snapchat.com/","https://twitter.com/","https://pinterest.com/","2024-11-05 12:37:34","2024-11-05 12:54:59")
;
